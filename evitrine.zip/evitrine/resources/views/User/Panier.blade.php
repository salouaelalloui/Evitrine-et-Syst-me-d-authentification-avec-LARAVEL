@extends('layouts.app')
@section('titre')
votre panier
@endsection
<style>
.prix{
text-align: center;
margin-left: 2000px;;
}
h2{
    margin-left: 1100px;
}
</style>

@section('content')
<h2> <a class="btn btn-outline-warning" href="Payer?id_panier={{$id_panier}}"> Payer </a> </h2>
<table id="table" class="table table-striped" class="table table-striped">

    <th > Nom </th>
    <th > Prix </th>
    <th > article </th>
    <th > supprimer </th>

@foreach($articles as $article)
<tr><td class="table-warning">
    {{$article["nom_art"]}}</td>
    <td class="table-warning">
    {{$article["prix"]}}</td>
    <td class="table-warning"><img src=" {{URL::asset ('/storage/uploads/Article/'.$article->imageArticle)}}"width="100" height="150"  ></td>
    <td class="table-warning"> <a class="btn btn-danger" href='deletearticle?id={{$article->id_article}}&&id_panier={{$id_panier}}'> Supprimer l'article </a></td>





</tr>
@endforeach
</table>
<span class="prix"><h4><strong> Prix Total : {{$prix}} DH</strong> </h4></span>





@endsection
