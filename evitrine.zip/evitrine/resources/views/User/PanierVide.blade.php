@extends('layout')
@section('titre')
votre panier
@endsection
@section('content')
<h1> Prix Total : 0 DH</h1>

<p> Panier vide
</p>






@endsection
