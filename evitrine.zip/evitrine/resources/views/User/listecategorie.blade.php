@extends('layouts.app')
@section('titre')
SELLE
@endsection
@section('content')

<style>
.div{
    margin-left : 150px;
    margin-right : 150px;
}
div.gallery{
    margin: 10px;
  /* border: 1px solid #ccc; */
  display: flex;
  justify-content: center;
  align-items: center;
  height: 600px;
  float: left;
  width: 272px;
  height: 500px;
  content: '';
  opacity: 3;
    -webkit-transition: opacity 0.9s ease 0s;

}
div.gallery:hover {
  border: 1px solid #777;
  opacity: 0.4;
}

div.gallery img {
  width: 100%;
  height: 400px;
  width: 270px;

}

div.desc {
  padding: 15px;
  text-align: center;
}
.h3{
    text-align: center;

	text-shadow: 2px 4px 3px rgba(0,0,0,0.3);

}
p{
    font-family: Verdana, sans-serif;
    text-shadow: 2px 4px 3px rgba(0,0,0,0.3);
    font-size: large;
    color: #79551A;
}
body {
background-color: #FEFFD5;
}
</style>

<body>
<h3 class="h3">Nos Catégories</h3>
  @foreach($list as $element)

  <div class="div">

    <div class="gallery">
  <div class="zoom colonne">
       <div>
          <a  href="/user/listeart?id_ctg={{$element['id_ctg']}}"><img src=" {{URL::asset ('/storage/uploads/Categorie/'.$element->imageCategorie)}}"class="img-fluid" width=200px height=300px  ></a>
        </div>
        <div class="desc">
             <p> {{$element['nom_ctg'] }} </p>
            </div>
        </div>

        </div >
</div>

        @endforeach

@endsection
</body>

