@extends('layouts.app')
@section('titre')
Articles
@endsection
@section('content')
<style>
.div{
    margin-left : 200px;
    margin-right : 200px;
}
div.gallery{
    margin: 10px;
  border: 1px solid #ccc;
  float: left;
  width: 272px;
  height: 500px;
margin-left: 10px;
}
div.gallery:hover {
  border: .1px solid #777;
}

div.gallery img {
  width: 100%;
  height: 400px;
  width: 270px;

}

div.desc {
  padding: 15px;
  text-align: center;
}
.h3{
    text-align: center;
    text-shadow: 2px 4px 3px rgba(0,0,0,0.3);
    padding-bottom: 20px;
    margin-right: 100px;
}
 #butt{
     margin-left :50px;
     margin-left :50px;
 }
 .zoom div img {
	-webkit-transform: scale(1);
	transform: scale(1);
	-webkit-transition: .4s ease-in-out;
	transition: .4s ease-in-out;
}
.zoom div:hover img {
	-webkit-transform: scale(1.2);
	transform: scale(1.2);
}
p{
    font-family: Verdana, sans-serif;
    text-shadow: 2px 4px 3px rgba(0,0,0,0.3);
    font-size: 300;
    text-align: center;
    color: #79551A;
}
.on{
    margin-left:70px;
}
</style>
     <h1 class="h3">Nos artilcles</h1>
@foreach($list as $element)
<div class="div">
    <div class="gallery">
    <div class="zoom colonne">
  <div> <a target="_blank" href=" {{URL::asset('/storage/uploads/Article/'.$element->imageArticle)}}"   > <img src=" {{URL::asset('/storage/uploads/Article/'.$element->imageArticle)}}"  width=200px height=300px  ></a>
</div >
  <span ><p >{{$element['nom_art'] }}  {{$element['prix'] }}DH</p></span>

<a id="butt" class="btn btn-warning "href="/Ajouterpanier?id_article={{$element['id_article']}}&&id={{$id}}">AJOUTER AU PANIER</a>
    </div>


</div >
</div>

@endforeach



<div class="on">{{$list->appends($_GET)->links("pagination::bootstrap-4")}}</div>







@endsection
