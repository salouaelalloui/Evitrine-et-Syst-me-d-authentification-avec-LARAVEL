@extends('layouts.app')

@section('content')
Welcome
@endsection
