@extends('.layout')
@section('content')
<style>
.mb-3{
    margin-left: 30px;
    margin-right: 30px;
border-color: yellow ;
}


</style>
<form action="modifierArt" method="get" >

<h1 style="margin-left: 20px;"> Modifier un Article</h1>

    <input type="hidden" name="id_article" value="{{$_GET['id_article']}}" >
<div class="mb-3">
   Nom de l'article <input class="form-control" type="text" name="nom_art" value="{{$_GET['nom_art']}}">
    </div>
    <div class="mb-3">
    <input  class="form-control" type="text" name="prix" value="{{$_GET['prix']}}">
</div>
<div class="mb-3">
    <input    class="btn btn-warning"  type="submit">
</div>
</form>
@endsection
