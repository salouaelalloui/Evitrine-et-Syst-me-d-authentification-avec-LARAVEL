
@extends('.layout')
<style>
.mb-3{
    margin-left: 30px;
    margin-right: 30px;
border-color: yellow ;
}

</style>
@section('content')

<form action="ajouter" method="POST" enctype="multipart/form-data">
@csrf
<h1 style="margin-left: 20px;"> Ajouter une Categorie </h1>
<div class="mb-3">


 Nom de catégorie:   <input  class="form-control" type="text" name="nom_ctg">

</div>
    <div class="mb-3">
    <input class="form-control" type="file" name="imageCategorie">
</div>
<div class="mb-3">
    <input   class="btn btn-warning" type="submit">
</div>
</form>
@endsection
