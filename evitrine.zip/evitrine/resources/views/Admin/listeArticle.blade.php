@extends('.layout')
@section('content')


<table id="table" class="table table-striped" class="table table-striped">

    <th > Nom </th>
    <th > Prix </th>
    <th > image </th>
    <th > supprimer </th>
    <th > modifier </th>
  @foreach($list as $element)




<tr><td class="table-warning"> <p>{{$element['nom_art'] }}</p> </td>
<td class="table-warning"><p>{{$element['prix'] }} DH </p></td>
<td class="table-warning"> <a target="_blank" href="{{  URL::asset ('/storage/uploads/Article/'.$element->imageArticle)}}">  <img  src="{{  URL::asset ('/storage/uploads/Article/'.$element->imageArticle)}}"  width="100" height="150" ></td>
<td class="table-warning"> <a class="btn btn-danger" href="/admin/supprimerArticle?id_article={{$element['id_article']}}"> Supprimer article </a> </td>
<td class="table-warning"> <a class="btn btn-success" href="/admin/modifierArticle?id_article={{$element['id_article']}}&&nom_art={{$element['nom_art']}}&&prix={{$element['prix']}}"> Modifier article </a> </td>



    </tr>

    @endforeach
</table>



{{$list->appends($_GET)->links("pagination::bootstrap-4")}}
@endsection
