@extends('.layout')
@section('content')



<a class="btn btn-sm btn-outline-secondary" href="nouvellecategorie">  New category </a> <br/>
<a  class="btn btn-sm btn-outline-secondary" href="listCategorie"> Liste Categorie </a>
@endsection
