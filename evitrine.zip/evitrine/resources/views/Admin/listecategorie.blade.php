@extends('.layout')
@section('content')
<style>
.div{
    margin-left : 130px;
}
div.gallery{
    margin: 10px;
  border: 1px solid #ccc;
  float: left;
  width: 290px;
  height: 560px;
  content: '';
  opacity: 3;
    -webkit-transition: opacity 0.9s ease 0s;


}
div.gallery:hover {
  border: 1px solid #777;
  opacity: 0.4;
}

div.gallery img {
  width: 100%;
  height: 400px;
  width: 288px;

}

div.desc {
  padding: 15px;

}

p{
    font-family: Verdana, sans-serif;
    text-shadow: 1px 3px 2px rgba(0,0,0,0.3);
    color: #79551A;
    text-align: center;

}
#id{
    margin-left: 1100px;
}

</style>


<a class="btn btn-sm btn-outline-secondary" id="id" href="nouvellecategorie">  New category </a> <br/>
  @foreach($list as $element)
<div class="div">
    <div class="gallery">

    <a href="/admin/listeart?id_ctg={{$element['id_ctg']}}"> <img  src=" {{asset ('/storage/uploads/Categorie/'.$element->imageCategorie)}}"width="600" height="400" ></a>
        <div class="desc"> <p> {{$element['nom_ctg'] }}</p> <a  class="btn btn-dark" href="/ajouterArticle?id_ctg={{$element['id_ctg']}}"> Ajouter un Article </a><a class="btn btn-warning"href="/supprimerCategorie?id_ctg={{$element['id_ctg']}}"> Supprimer la catégorie</a>
        </div>

    </div >
</div>


    @endforeach

@endsection
