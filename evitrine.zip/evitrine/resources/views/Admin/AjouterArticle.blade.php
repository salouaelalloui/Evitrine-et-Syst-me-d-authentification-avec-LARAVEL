
@extends('.layout')
<style>
.mb-3{
    margin-left: 30px;
    margin-right: 30px;
border-color: yellow ;
}


</style>
@section('content')

<form action="ajouterArt" method="POST" enctype="multipart/form-data">
@csrf
<h1 style="margin-left: 20px;">Ajouter des articles</h1>
<div class="mb-3">

    <input type="hidden" name="id_ctg"value="{{$_GET['id_ctg']}}" >
</div>
    <div class="mb-3">
    <label>Nom de l'article :</label>
    <input class="form-control" type="text" name="nom_art">
</div>
    <div class="mb-3">
    <label>Prix:</label>
    <input class="form-control" type="text" name="prix">
</div>
    <div class="mb-3">

    <input class="form-control" type="file" name="imageArticle">
</div>
<div class="mb-3">
<input  class="btn btn-warning" type="submit">
</div>

</form>
@endsection
