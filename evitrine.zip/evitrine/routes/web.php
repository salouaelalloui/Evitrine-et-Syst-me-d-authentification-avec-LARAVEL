<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PanierController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\CategorieController;
use App\Http\Controllers\ArticlePanierController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Middleware\CheckRole;
use App\Http\Controllers\Auth\LoginController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Auth::routes();
// Route::get("/",[LoginController::class, 'authenticated']);
// Route::get("/",[CategorieController::class,"listu"])->name("racine");


Route::get('/nouvellecategorie',function(){
    return view("Admin/AjouterCategorie");
})->middleware('role:admin');

Route::post('/ajouter',[CategorieController::class,"save"]);
// Route::get("/ajouterArticle",function(){
//     return view("AjouterArticle");
// });
Route::get("ajouterArt",[ArticleController::class,"save"]);
Route::get("supprimerCategorie",[CategorieController::class,"supprimer"]);

Route::get("/listeart",[ArticleController::class,"lista"]);

Route::get("/panier",[ArticlePanierController::class,"save"])->name('artp');
//-----
Route::get('/nouvellecategorie',function(){
    return view("Admin/AjouterCategorie");
})->middleware("role:admin");
Route::get("/listCategorie",[CategorieController::class,"lista"])->name("listecat");
Route::post('/ajouter',[CategorieController::class,"save"])->middleware("role:admin");

Route::get("/ajouterArticle",function(){
    return view("Admin/AjouterArticle");
})->middleware("role:admin");

Route::post("ajouterArt",[ArticleController::class,"save"])->name("ajouterArt")->middleware("role:admin");
Route::get("supprimerCategorie",[CategorieController::class,"supprimer"])->middleware("role:admin");

Route::get("admin/supprimerArticle",[ArticleController::class,"supprimer"])->middleware("role:admin");
Route::get('admin/listeart', [ArticleController::class,"lista"])->name("listeart");
Route::get("admin/modifierArticle",function(){ return view("Admin.modifierArticle");})->middleware("role:admin");
Route::get("admin/modifierArt",[ArticleController::class,"modifier"])->middleware("role:admin");
//---
// Route::get("/panier",[PanierController::class,"save"]);

// Route::get('/listeart/{n}', function ($n) {
//     return 'User '.$n;
// });
/*Route::get('/{n}',function($n){
    return $n;
}); */



Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/admin', [AdminController::class,"index"])->name("admin")->middleware("role:admin");
 Route::get("/user",[CategorieController::class,"listu"])->name("user");
 Route::get("user/listeart",[ArticleController::class,"listu"]);
 Route::get('Ajouterpanier',[ArticleController::class,'ajouter']);
 Route::get('VoirPanier',[PanierController::class,'show']);
 Route::get('Payer',[PanierController::class,'supprimer']);
 Route::get('deletearticle',[PanierController::class,'deletearticle']);
