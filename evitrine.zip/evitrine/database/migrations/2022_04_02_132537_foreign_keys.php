<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table("articles",function(Blueprint $table){
            $table->foreign('categorie_id')->references('id_ctg')->on('categories')
            ->onDelete('cascade')
            ->onUpdate('cascade');
        });
        Schema::table("article_paniers",function(Blueprint $table){
            $table->foreign('article_id')->references('id_article')->on('articles')
            ->onDelete('cascade')
            ->onUpdate('cascade');
        });
        Schema::table("article_paniers",function(Blueprint $table){
            $table->foreign('panier_id')->references('id_panier')->on('paniers')
            ->onDelete('cascade')
            ->onUpdate('cascade');
        });




        Schema::table("role_user",function(Blueprint $table){
        $table->foreign('user_id')->references('id')->on('users')
        ->onDelete('cascade')
        ->onUpdate('cascade'); 
    });
    Schema::table("role_user",function(Blueprint $table){
        $table->foreign('role_id')->references('id')->on('roles')
        ->onDelete('cascade')
        ->onUpdate('cascade'); 
    });
    Schema::table("paniers",function(Blueprint $table){
        $table->foreign('user_id')->references('id')->on('users')
        ->onDelete('cascade')
        ->onUpdate('cascade'); 
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
