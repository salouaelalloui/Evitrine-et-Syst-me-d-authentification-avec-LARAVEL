<?php $__env->startSection('titre'); ?>
Selle
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- <a href="nouvellecategorie">  New category </a> <br/> -->
<!-- <a href="listCategorie"> Liste Categorie </a> -->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Desktop\evitrine\resources\views/welcome.blade.php ENDPATH**/ ?>