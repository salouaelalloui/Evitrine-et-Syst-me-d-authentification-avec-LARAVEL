<style>
.mb-3{
    margin-left: 30px;
    margin-right: 30px;
border-color: yellow ;
}


</style>
<?php $__env->startSection('content'); ?>

<form action="ajouterArt" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<h1 style="margin-left: 20px;">Ajouter des articles</h1>
<div class="mb-3">

    <input type="hidden" name="id_ctg"value="<?php echo e($_GET['id_ctg']); ?>" >
</div>
    <div class="mb-3">
    <label>Nom de l'article :</label>
    <input class="form-control" type="text" name="nom_art">
</div>
    <div class="mb-3">
    <label>Prix:</label>
    <input class="form-control" type="text" name="prix">
</div>
    <div class="mb-3">

    <input class="form-control" type="file" name="imageArticle">
</div>
<div class="mb-3">
<input  class="btn btn-warning" type="submit">
</div>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Downloads\evitrine\resources\views/Admin/AjouterArticle.blade.php ENDPATH**/ ?>