<a href="nouvellecategorie">  New category </a> <br/>
<a href="listCategorie"> Liste Categorie </a><?php /**PATH C:\evitrine\resources\views/welcome.blade.php ENDPATH**/ ?>