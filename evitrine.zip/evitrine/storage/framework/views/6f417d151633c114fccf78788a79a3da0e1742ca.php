<form action="ajouter" method="POST" enctype="multipart/form-data"> 
<?php echo csrf_field(); ?>
<h1> Nom Categorie <h1>
    <input type="text" name="nom_ctg"> 
    <input type="file" name="imageCategorie"> 

    <input type="submit">
</form><?php /**PATH C:\Users\HP\Desktop\saloua\evitrine\resources\views/Admin/AjouterCategorie.blade.php ENDPATH**/ ?>