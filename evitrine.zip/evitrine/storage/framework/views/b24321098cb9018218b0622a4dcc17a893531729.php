<a href="nouvellecategorie">  New category </a> <br/>
<a href="listCategorie"> Liste Categorie </a><?php /**PATH E:\evitrine\resources\views/Admin/home.blade.php ENDPATH**/ ?>