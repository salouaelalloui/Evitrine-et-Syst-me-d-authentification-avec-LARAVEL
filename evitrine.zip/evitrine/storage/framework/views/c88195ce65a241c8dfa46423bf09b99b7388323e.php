<?php $__env->startSection('titre'); ?>
SELLE
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- <table> -->

    <!-- <th>  </th> -->
<h3>Nos Catégories</h3>
  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- <tr><td> -->
     <a href="/listeart?id_ctg=<?php echo e($element['id_ctg']); ?>"> <?php echo e($element['nom_ctg']); ?> </a></td>
<!--
<td><a href="/ajouterArticle?id_ctg=<?php echo e($element['id_ctg']); ?>"> Ajouter Article </a> </td>
<td> <a href="/supprimerCategorie?id_ctg=<?php echo e($element['id_ctg']); ?>"> Supprimer </a></td> -->

    <!-- </tr> -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- </table> -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Desktop\a\evitrine\resources\views/listecategorie.blade.php ENDPATH**/ ?>