<?php $__env->startSection('titre'); ?>
votre panier
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
foreach($lister as $liste)
<p><?php echo e($liste['id_panier']); ?></p>
endforeach



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Desktop\evitrine\resources\views/panier.blade.php ENDPATH**/ ?>