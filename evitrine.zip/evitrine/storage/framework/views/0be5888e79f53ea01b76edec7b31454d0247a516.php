<?php $__env->startSection('titre'); ?>
Ajouter categorie
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="ajouter">

<h1> Nom Categorie <h1>
    <input type="text" name="nom_ctg">
    <input type="submit">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Desktop\evitrine\resources\views/AjouterCategorie.blade.php ENDPATH**/ ?>