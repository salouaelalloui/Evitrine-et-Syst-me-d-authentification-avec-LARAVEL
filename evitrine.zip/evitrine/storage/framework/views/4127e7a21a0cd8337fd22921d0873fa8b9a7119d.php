<table>
    
    <th> Nom </th>
    <th> Prix </th>
    
  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
 
<tr><td><?php echo e($element['nom_art']); ?> </td> 
<tr><td><?php echo e($element['prix']); ?> </td> 




    </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\evitrine\resources\views/listeArticle.blade.php ENDPATH**/ ?>