<?php $__env->startSection('content'); ?>


<table id="table" class="table table-striped" class="table table-striped">

    <th > Nom </th>
    <th > Prix </th>
    <th > image </th>
    <th > supprimer </th>
    <th > modifier </th>
  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




<tr><td class="table-warning"> <p><?php echo e($element['nom_art']); ?></p> </td>
<td class="table-warning"><p><?php echo e($element['prix']); ?> DH </p></td>
<td class="table-warning"> <a target="_blank" href="<?php echo e(URL::asset ('/storage/uploads/Article/'.$element->imageArticle)); ?>">  <img  src="<?php echo e(URL::asset ('/storage/uploads/Article/'.$element->imageArticle)); ?>"  width="100" height="150" ></td>
<td class="table-warning"> <a class="btn btn-danger" href="/admin/supprimerArticle?id_article=<?php echo e($element['id_article']); ?>"> Supprimer article </a> </td>
<td class="table-warning"> <a class="btn btn-success" href="/admin/modifierArticle?id_article=<?php echo e($element['id_article']); ?>&&nom_art=<?php echo e($element['nom_art']); ?>&&prix=<?php echo e($element['prix']); ?>"> Modifier article </a> </td>



    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>



<?php echo e($list->appends($_GET)->links("pagination::bootstrap-4")); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Downloads\evitrine\resources\views/Admin/listeArticle.blade.php ENDPATH**/ ?>