<?php $__env->startSection('titre'); ?>
Articles
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
.div{
    margin-left : 200px;
    margin-right : 200px;
}
div.gallery{
    margin: 10px;
  border: 1px solid #ccc;
  float: left;
  width: 272px;
  height: 500px;
margin-left: 10px;
}
div.gallery:hover {
  border: .1px solid #777;
}

div.gallery img {
  width: 100%;
  height: 400px;
  width: 270px;

}

div.desc {
  padding: 15px;
  text-align: center;
}
.h3{
    text-align: center;
    text-shadow: 2px 4px 3px rgba(0,0,0,0.3);
    padding-bottom: 20px;
    margin-right: 100px;
}
 #butt{
     margin-left :50px;
     margin-left :50px;
 }
 .zoom div img {
	-webkit-transform: scale(1);
	transform: scale(1);
	-webkit-transition: .4s ease-in-out;
	transition: .4s ease-in-out;
}
.zoom div:hover img {
	-webkit-transform: scale(1.2);
	transform: scale(1.2);
}
p{
    font-family: Verdana, sans-serif;
    text-shadow: 2px 4px 3px rgba(0,0,0,0.3);
    font-size: 300;
    text-align: center;
    color: #79551A;
}
.on{
    margin-left:70px;
}
</style>
     <h1 class="h3">Nos artilcles</h1>
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="div">
    <div class="gallery">
    <div class="zoom colonne">
  <div> <a target="_blank" href=" <?php echo e(URL::asset('/storage/uploads/Article/'.$element->imageArticle)); ?>"   > <img src=" <?php echo e(URL::asset('/storage/uploads/Article/'.$element->imageArticle)); ?>"  width=200px height=300px  ></a>
</div >
  <span ><p ><?php echo e($element['nom_art']); ?>  <?php echo e($element['prix']); ?>DH</p></span>

<a id="butt" class="btn btn-warning "href="/Ajouterpanier?id_article=<?php echo e($element['id_article']); ?>&&id=<?php echo e($id); ?>">AJOUTER AU PANIER</a>
    </div>


</div >
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<div class="on"><?php echo e($list->appends($_GET)->links("pagination::bootstrap-4")); ?></div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Downloads\evitrine\resources\views/User/listeArticle.blade.php ENDPATH**/ ?>