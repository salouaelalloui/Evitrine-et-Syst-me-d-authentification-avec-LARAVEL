<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <title><?php echo $__env->yieldContent('titre'); ?></title>
</head>
<body>
<header>
<!-- <h1 class="header-title"><em>SELLE</em></h1> -->

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">SELLE</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link active" href="/">Acceuil <span class="sr-only"></span></a>
      <a class="nav-item nav-link" href="/panier">Panier</a>

    </div>
  </div>
</nav>
</header>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>">
    </script>
<footer>&copy; <?php echo date("Y");?></footer>
</body>
</html>
<?php /**PATH C:\Users\SALOUA\Desktop\a\evitrine\resources\views/layout.blade.php ENDPATH**/ ?>