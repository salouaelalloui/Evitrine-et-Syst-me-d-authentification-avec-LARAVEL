<?php $__env->startSection('titre'); ?>
votre panier
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
foreach($list as $liste)
<p>




</p>
endforeach




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Desktop\evitrine\resources\views/Panier.blade.php ENDPATH**/ ?>