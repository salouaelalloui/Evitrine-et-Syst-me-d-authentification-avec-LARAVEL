<?php $__env->startSection('titre'); ?>
Articles
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

     <h3>Nos artilcles</h3>
<table>
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td>
    <img src=" <?php echo e(asset ('uploads/Article/'.$element->image)); ?>" width=200px height=300px alt="robe" >
<p><?php echo e($element['nom_art']); ?>  <?php echo e($element['prix']); ?>DH</p>

<a href="/panier?id_article=<?php echo e($element['id_article']); ?>">AJOUTER AU PANIER</a>
</td>







    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>



<?php echo e($list->links()); ?>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Desktop\evitrine\resources\views/listeArticle.blade.php ENDPATH**/ ?>