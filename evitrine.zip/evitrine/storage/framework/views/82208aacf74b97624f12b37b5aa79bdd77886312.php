<?php $__env->startSection('content'); ?>



<a class="btn btn-sm btn-outline-secondary" href="nouvellecategorie">  New category </a> <br/>
<a  class="btn btn-sm btn-outline-secondary" href="listCategorie"> Liste Categorie </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Downloads\evitrine\resources\views/Admin/home.blade.php ENDPATH**/ ?>