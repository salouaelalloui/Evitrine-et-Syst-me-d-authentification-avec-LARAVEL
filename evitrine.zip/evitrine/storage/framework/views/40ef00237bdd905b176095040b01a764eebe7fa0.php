<a href="nouvellecategorie">  New category </a> <br/>
<a href="listCategorie"> Liste Categorie </a><?php /**PATH C:\Users\HP\Desktop\saloua\evitrine\resources\views/Admin/home.blade.php ENDPATH**/ ?>