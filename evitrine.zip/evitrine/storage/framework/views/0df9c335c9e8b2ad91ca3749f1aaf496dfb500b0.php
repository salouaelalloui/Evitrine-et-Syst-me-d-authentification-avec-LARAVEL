<form action="ajouter"> 

<h1> Nom Categorie <h1>
    <input type="text" name="nom_ctg"> 
    <input type="submit">
</form><?php /**PATH C:\evitrine\resources\views/AjouterCategorie.blade.php ENDPATH**/ ?>