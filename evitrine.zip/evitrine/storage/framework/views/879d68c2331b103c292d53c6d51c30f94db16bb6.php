<form action="ajouterArt"> 

<h1> Nom Article <h1>
<input type="hidden" name="id_ctg"value="<?php echo e($_GET['id_ctg']); ?>"> 
    <input type="text" name="nom_art"> 
    <input type="text" name="prix"> 
    <input type="submit">
</form><?php /**PATH C:\evitrine\resources\views/AjouterArticle.blade.php ENDPATH**/ ?>