<?php $__env->startSection('titre'); ?>
votre panier
<?php $__env->stopSection(); ?>
<style>
.prix{
text-align: center;
margin-left: 2000px;;
}
h2{
    margin-left: 1100px;
}
</style>

<?php $__env->startSection('content'); ?>
<h2> <a class="btn btn-outline-warning" href="Payer?id_panier=<?php echo e($id_panier); ?>"> Payer </a> </h2>
<table id="table" class="table table-striped" class="table table-striped">

    <th > Nom </th>
    <th > Prix </th>
    <th > article </th>
    <th > supprimer </th>

<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td class="table-warning">
    <?php echo e($article["nom_art"]); ?></td>
    <td class="table-warning">
    <?php echo e($article["prix"]); ?></td>
    <td class="table-warning"><img src=" <?php echo e(URL::asset ('/storage/uploads/Article/'.$article->imageArticle)); ?>"width="100" height="150"  ></td>
    <td class="table-warning"> <a class="btn btn-danger" href='deletearticle?id=<?php echo e($article->id_article); ?>&&id_panier=<?php echo e($id_panier); ?>'> Supprimer l'article </a></td>





</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<span class="prix"><h4><strong> Prix Total : <?php echo e($prix); ?> DH</strong> </h4></span>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SALOUA\Downloads\evitrine\resources\views/User/Panier.blade.php ENDPATH**/ ?>