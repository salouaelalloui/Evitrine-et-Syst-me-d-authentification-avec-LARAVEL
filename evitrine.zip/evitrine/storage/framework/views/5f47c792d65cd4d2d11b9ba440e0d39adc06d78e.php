<table>
    
    <th> Nom </th>
    
  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
 
<tr><td> <a href="listeart?id_ctg=<?php echo e($element['id_ctg']); ?>"> <?php echo e($element['nom_ctg']); ?> </a></td> 

<td><a href="/ajouterArticle?id_ctg=<?php echo e($element['id_ctg']); ?>"> Ajouter Article </a> </td>
<td> <a href="/supprimerCategorie?id_ctg=<?php echo e($element['id_ctg']); ?>"> Supprimer </a></td>
<td>    <img  src=" <?php echo e(URL::asset ('/storage/uploads/Categorie/'.$element->imageCategorie)); ?>" ></td>
    </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\HP\Desktop\saloua\evitrine\resources\views/Admin/listecategorie.blade.php ENDPATH**/ ?>