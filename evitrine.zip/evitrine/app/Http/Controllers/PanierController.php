<?php

namespace App\Http\Controllers;

use App\Models\Panier;
use App\Models\Article_Panier;
use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
class PanierController extends Controller
{
    public function show(){
        $id=Auth::user()->id;
       $panier=Panier::where('user_id',$id)->first();
       if($panier!=null){
       $articles_Paniers=Article_Panier::where('panier_id',$panier->id_panier)->get();;
       $articles=array();
       foreach($articles_Paniers as $article)
       {
           array_push($articles,Article::find($article->article_id));
       }
        $prix=$panier->prix_total;
        $id_panier=$panier->id_panier;
       return view('User/Panier')->with('articles',$articles)->with('prix',$prix)->with('id_panier',$id_panier);

    }
else {
    return view('User/PanierVide');
}}


    public function save(Request $request){
   }
    public function list(Request $request){
        $list=Panier::where("panier_id",$request['id_panier'])->get();
        return Redirect::route('artp',['list'=>$list]);
}
public function supprimer(Request $request){
    Panier::find($request['id_panier'])->delete();
    return CategorieController::listu() ;

}
public function deletearticle(Request $request){
    $id=$request['id'];

    $article=Article::find($id)->first();
    $prix_article=$article->prix;
    $id_panier=$request['id_panier'];

    $panier=Panier::find($id_panier)->first();

    $nv_prix=$panier->prix_total-$prix_article;
    Article_Panier::where('article_id',$id)->delete();


    Panier::find($panier->id_panier)->update(['prix_total'=>$nv_prix]);
    return CategorieController::listu();

}



}
