<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    protected function authenticated( Request $request,$user)
    {
        {
            $uid =  $user->id;
            $role= DB::table('role_user')
                ->where('role_user.user_id','=',$uid)
                ->join('roles', 'role_user.role_id', '=', 'roles.id')
                ->select('roles.name as name')
                ->first();
            if ($role->name=='admin') {
                return redirect()->route('admin');
            } elseif($role->name=='internaute') {
                return redirect()->route('user');
            }else{
            return redirect("racine");
           } } }
}
