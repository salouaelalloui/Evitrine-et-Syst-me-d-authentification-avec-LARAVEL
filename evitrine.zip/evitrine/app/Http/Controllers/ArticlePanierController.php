<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Article_Panier;
use Illuminate\Support\Facades\Redirect;

class ArticlePanierController extends Controller
{
    public function save(Request $request){
        $artp=new  Article_Panier();

        $artp->article_id=$request["id_article"];
         $artp->panier_id=$request["id_panier"];
        $artp->save();
       $list=Article_Panier::where("article_id",$request['id_article'], "panier_id",$request['id_panier'])->get();
         return view('Panier',["list",$list]);

    }

}
