<?php

namespace App\Http\Controllers;
use App\Models\Panier;
use App\Models\Article;
use Illuminate\Http\Request;

use App\Models\Article_Panier;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\CategorieController;


class ArticleController extends Controller
{
    public function save(Request $request){
        $art=new Article();
        $art->id_article=$request["id_article"];
        $art->nom_art=$request["nom_art"];
        $art->prix=$request["prix"];
        $art->categorie_id=$request["id_ctg"];
       // $file = $request->file('imageArticle')->hashName(). $request->file('imageArticle')->clientExtension();
       $file=time().".jpg";
       $ff=$request->file('imageArticle')->storePubliclyAs('/public/uploads/Article',$file);
       str_replace('public', 'storage', $ff);
   //   $path = Storage::putFileAs('uploads\Article', $file);
      //  $path = $request->file('imageArticle')->store('C:\evitrine\public\uploads\Article');
    //  $path = Storage::putFile('uploads\Article', $request->file('imageArticle'));

      $art->imageArticle=$file;
        $art->save();
        $list=Article::where("categorie_id",$request['id_ctg'])->paginate(5);
        return view ('Admin/listeArticle',["list"=>$list]);



    }
    public function supprimer(Request $request){
        Article::find($request["id_article"])->delete();
        return CategorieController::lista();

      }
      public function modifier(Request $request){

          $nom=$request['nom_art'];
          $prix=$request['prix'];

          $id=$request['id_article'];

        Article::find($id)->update(['nom_art'=>$nom]);
          Article::find($id)->update(['prix'=>$prix]);


          return CategorieController::lista() ;
      }
    public function listu(Request $request){
        $article=new Article();
        $id=Auth::user()->id;
        $list=$article->where("categorie_id",$request['id_ctg'])->paginate(6);
        return view('User/listeArticle')->with('list',$list)->with('id',$id);

    }

    public function lista(Request $request){

      $list=Article::where("categorie_id",$request["id_ctg"])->paginate(6);

      return view('Admin/listeArticle',['list'=>$list]);
   }
   public function ajouter(Request $request){
    $p=Panier::where('user_id',$request['id'])->first();
    $a=Article::where('id_article',$request['id_article'])->first();
    if($p==null){
    $pan=new Panier();
    $pan->id_panier=$request['id_panier'];
    $pan->user_id=$request['id'];
    $pan->prix_total=$a->prix;
    $pan->save();
    $pp=new Article_Panier();
    $pp->article_id=$request['id_article'];
    $pa=DB::table('paniers')->where('user_id',$request['id'])->latest('upload_time')->first();
    // $pa=Panier::where('user_id',$request['id'])->last();
    $pp->panier_id=$pa->id_panier;
    $pp->save();
    return redirect('listeCategorie');

    }
else {


    $pp=new Article_Panier();
    $prixx=Article::find($request['id_article'])->first();

    $prix=$prixx->prix;
    $pp->article_id=$request['id_article'];
    $pp->panier_id=$p->id_panier;
    Panier::find($p->id_panier)->update(['prix_total' => $p->prix_total+$prix]);

    $p->prix_total=$p->prix_total+$prix;

    $pp->save();
    return CategorieController::listu();
}

   }
}

