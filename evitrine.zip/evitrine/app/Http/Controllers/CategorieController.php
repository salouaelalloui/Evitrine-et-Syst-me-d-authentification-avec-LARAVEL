<?php

namespace App\Http\Controllers;
use App\Models\Categorie;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class CategorieController extends Controller
{
    public function save(Request $request){
        $cat=new Categorie();
       $cat->nom_ctg=$request["nom_ctg"];
       $file=time().".jpg";
        $ff=$request->file('imageCategorie')->storePubliclyAs('/public/uploads/Categorie',$file);
        str_replace('public', 'storage', $ff);
        $cat->imageCategorie=$file;

       $cat->save();
       return view('Admin/home');
        }
        public function supprimer(Request $request){


            // $cat::find($id)->delete();
            Categorie::find($request["id_ctg"])->delete();
            return view("Admin/home");
        }
        public function modifier(Request $request){
            Categorie::find($request["id"])->update(["nom_ctg"=>$request["nom"]]);
        }



        public  static function listu(){

            $list=Categorie::all();
            return view('User/listecategorie',['list'=>$list]);

        }
        public static function lista(){

            $list=Categorie::all();
            return view('Admin/listecategorie',['list'=>$list]);
        }

        public function liste(){

            $list=Categorie::all();
            return view('Admin/listecategorie',['list'=>$list]);
        }

 public function __construct()
 {
 $this->middleware('auth');
 }
 public function index(Request $request)
 {
 $request->user()->authorizeRoles(['internaute ', 'admin']);
 return view('home');
 }
 /* function qui didié pour les admin
 public function someAdminStuff(Request $request)
 {
 $request->user()->authorizeRoles('admin');
// rmaplacer par une vue selon votre projet
 return view(‘some.view’);
 }
 */
}


