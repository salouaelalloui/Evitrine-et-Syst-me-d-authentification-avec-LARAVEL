<?php

namespace App\Models;

use App\Models\Article;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Categorie extends Model
{
    use HasFactory;
    protected $fillable = [
        
        'nom_ctg',

    ];
    //because find assume that ,my primary key is "id"
    protected $primaryKey = 'id_ctg';


    public function articles()
{
 return $this->hasMany(Article::class);
}

}
