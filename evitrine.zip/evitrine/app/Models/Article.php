<?php

namespace App\Models;

use App\Models\Panier;
use App\Models\Categorie;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Article extends Model
{
    use HasFactory;
    protected $table='articles';
    protected $fillable = [

        'nom_art',
        'prix',
        'image',
    ];
    protected $primaryKey='id_article';
        public function categorie()
{
 return $this->belongsTo(Categorie::class);
}

public function paniers()
{
 return $this->belongsToMany(Panier::class);
}
}
