<?php

namespace App\Models;

use App\Models\Article;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Panier extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_panier',
        'quantite',
        'prix_total',
        'user_id'
    ];
    protected $primaryKey="id_panier";
    public function articles()
    {
     return $this->belongsToMany(Article::class);
    }
    public function user(){
        return $this->belongsTo(User::class);
    }
}


